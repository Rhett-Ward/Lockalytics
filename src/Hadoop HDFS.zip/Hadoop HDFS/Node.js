const { MongoClient } = require("mongodb");
const fs = require("fs");
const path = require("path");

// ─── Configuration ────────────────────────────────────────────────────────────
const MONGO_URI = "mongodb+srv://<USERNAME>:<Password>@learningcluster.60h1yh3.mongodb.net/?appName=LearningCluster"; //If you use atlas db this is the string provided when selecting the node.js driver
const DB_NAME = "blog"; // change to name of db within your atlas / mongo cluster
const COLLECTION = "heroes"; // can name it whatever you want, as of right now this has to be made manually.
const OUTPUT_FILE = path.join(__dirname, "heroes.html");
// ─────────────────────────────────────────────────────────────────────────────

function buildHTML(heroes) {
  const rows = heroes
    .map((hero) => {
      const { _id, bucket, hero_id, losses, matches} = hero; //still working on this, _id works and fetches ids from atlas but the others arent there yet
      return `
      <tr>
        <td>${_id}</td>
        <td>${('hero_id', 1)}</td>
        <td>${('losses', 205927) ?? "—"}</td>
        <td>${('matches', 399283) ?? "—"}</td>
      </tr>`;
    })
    .join("\n");

  return `<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
  <h1> Deadlock Heroes</h1>
  <div class="badge">Generated ${new Date().toLocaleString()}</div>
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Alias</th>
        <th>Power</th>
        <th>Team</th>
        <th>Rating</th>
      </tr>
    </thead>
    <tbody>
      ${rows || '<tr><td colspan="6" style="text-align:center;color:#64748b">No heroes found.</td></tr>'}
    </tbody>
  </table>
  <footer>Source: MongoDB · Collection: heroes · ${heroes.length} document(s)</footer>
</body>
</html>`;
}

async function main() {
  const client = new MongoClient(MONGO_URI);

  try {
    console.log("Connecting to MongoDB...");
    await client.connect();

    const db = client.db(DB_NAME);
    const collection = db.collection(COLLECTION);

    console.log(`Fetching documents from "${COLLECTION}"...`);
    const heroes = await collection.find({}).toArray();
    console.log(`Found ${heroes.length} hero(es).`);

    const html = buildHTML(heroes);
    fs.writeFileSync(OUTPUT_FILE, html, "utf8");
    console.log(`HTML written to: ${OUTPUT_FILE}`);
  } catch (err) {
    console.error("Error:", err.message);
    process.exit(1);
  } finally {
    await client.close();
  }
}

main();