from email.policy import strict

import deadlock_api_client
from deadlock_api_client.rest import ApiException
from pprint import pprint
import csv
import pandas as pd

from pymongo import MongoClient
from pymongo import server_api
from pymongo.server_api import ServerApi
from pymongo import database
from pymongo import collection


def main():
    # Defining the host is optional and defaults to https://api.deadlock-api.com
    # See configuration.py for a list of all supported configuration parameters.
    configuration = deadlock_api_client.Configuration(
        host = "https://api.deadlock-api.com"
    )



    # Enter a context with an instance of the API client
    with deadlock_api_client.ApiClient(configuration) as api_client:
        # Create an instance of the API class
        api_instance = deadlock_api_client.AnalyticsApi(api_client)
        hero_id = 2 # int | See more: <https://assets.deadlock-api.com/v2/heroes>
        game_mode = 'normal' # str | Filter matches based on their game mode. Valid values: `normal`, `street_brawl`. **Default:** `normal`. (optional)
        #min_unix_timestamp = 1768003200 # int | Filter matches based on their start time (Unix timestamp). **Default:** 30 days ago. (optional) (default to 1768003200)
        #max_unix_timestamp = 56 # int | Filter matches based on their start time (Unix timestamp). (optional)
        #min_duration_s = 56 # int | Filter matches based on their duration in seconds (up to 7000s). (optional)
        #max_duration_s = 56 # int | Filter matches based on their duration in seconds (up to 7000s). (optional)
        #min_ability_upgrades = 56 # int | Filter players based on their minimum number of ability upgrades over the whole match. (optional)
        #max_ability_upgrades = 56 # int | Filter players based on their maximum number of ability upgrades over the whole match. (optional)
        #min_networth = 56 # int | Filter players based on their final net worth. (optional)
        #max_networth = 56 # int | Filter players based on their final net worth. (optional)
        #min_average_badge = 56 # int | Filter matches based on the average badge level (tier = first digits, subtier = last digit) of *both* teams involved. See more: <https://assets.deadlock-api.com/v2/ranks> (optional)
        #max_average_badge = 56 # int | Filter matches based on the average badge level (tier = first digits, subtier = last digit) of *both* teams involved. See more: <https://assets.deadlock-api.com/v2/ranks> (optional)
        #min_match_id = 56 # int | Filter matches based on their ID. (optional)
        #max_match_id = 56 # int | Filter matches based on their ID. (optional)
        min_matches = 100 # int | The minimum number of matches played for an ability order to be included in the response. (optional) (default to 20)
        #account_id = 56 # int | Filter for matches with a specific player account ID. (optional)
        account_ids = [1081191959] # List[int] | Comma separated list of account ids to include (optional)

        try:

            uri = "mongodb+srv://<Username>:<password>@learningcluster.60h1yh3.mongodb.net/?appName=LearningCluster"
            client = MongoClient(uri)

            try:
                client.admin.command('ping')
                pprint("Pong!")
            except Exception as e:
                print(e)

            # Ability Order Stats
            api_response = api_instance.hero_stats()
            print("The response of AnalyticsApi->ability_order_stats:\n")

            database = client["blog"] #connect to database

            try:
                database.create_collection("heroes")
            except Exception as e:
                print("Collection already exists")

            output_file_path = 'output.csv'

            #region
            # Open the file in write mode ('w') using a context manager
            with open(output_file_path, mode='w', newline='') as csvfile:
                # Create a csv writer object
                csv_writer = csv.writer(csvfile, delimiter=',')

                # Write the data rows
                csv_writer.writerows(api_response)

                print(f"CSV file '{output_file_path}' created successfully.")
            #endregion
            ds = pd.read_csv('output.csv')
            mydict = ds.to_dict("list")

            print(mydict)

            database.heroes.insert_one(mydict)


            #output_file_path = 'output.csv'

            # Open the file in write mode ('w') using a context manager
            #with open(output_file_path, mode='w', newline='') as csvfile:
                # Create a csv writer object
                #csv_writer = csv.writer(csvfile, delimiter=',')

                # Write the data rows
                #csv_writer.writerows(api_response)

            #print(f"CSV file '{output_file_path}' created successfully.")

        except ApiException as e:
            print("Exception when calling AnalyticsApi->ability_order_stats: %s\n" % e)

if __name__ == '__main__':
    main()